##Semester Project Draft 2

#I hereby certify that this program is 
#solely the result of my own work and is in compliance with the 
#Academic Integrity policy of the course syllabus.


import random
import Draw
import math
import time

#Approved global variables

#Start button x,y start coordinates
MESSAGE_X=350
MESSAGE_Y=250

#Message board x,y start coordinates
MESSAGE_MID_X=350
MESSAGE_MID_Y=230

#Message board x,y size
MESSAGE_WIDTH=400
MESSAGE_LENGTH=300

#Canvas size
CANVAS_WIDTH = 1100
CANVAS_HEIGHT = 800

#Horizontal and verticall space between the start corner of a card
#and the next start corner
HORIZ_CARD_SPACE=160
VERT_CARD_SPACE=200

#Card width and length
CARD_WIDTH=150
CARD_LENGTH=190

#Location to start the first card
START_X=40
START_Y=40

#Location of side button x axis
SIDE_BUTTON_X=900
#Location of side button y starting point
SIDE_BUTTON_Y=80

#Width of the button
HORIZ_BUTTON_CARD_SPACE=120
VERT_BUTTON_CARD_SPACE=80

##Middle set logo for start and end pages
#LOGO_CENTER_X=490
#LOGO_CENTER_Y=40

#Statistics Variables
STRING_STAT_X=410
GIF_STAT_X=460
STAT_Y=120
STAT_SPACE=40

#Custom color gray
NEW_GRAY=Draw.color(114,114,114)

def main():
    
    #Create the canvas
    Draw.setCanvasSize(CANVAS_WIDTH,CANVAS_HEIGHT)
    Draw.show()
    
    #Invoke the intro board to click to start the game
    introBoard()       
    
def playGame():

    #Start the time
    startTime=time.time()
    
    #Variable to keep track of sets completed starts at 0
    setsCompleted=0   
    
    clickedTry=[]    
    
    #Create the deck of card
    deck = createDeck()
    
    #Fill the board list
    boardList, deck = fillBoardList(deck)
    
    #Initialize the current time
    currentTime=0
    minutes=0
    seconds=0
    
    newX = 0
    newY = 0     
    
    #While the game is still able to be played
    while len(boardList) > 0:
        
        #Check if the user clicked
        #If the user clicked, update the variables
        if Draw.mousePressed():
            
            newX = Draw.mouseX()
            newY = Draw.mouseY()          

            #If they clicked the "End Game" button, 
            #end the game and display the stats
            if newX>=SIDE_BUTTON_X and newX<=SIDE_BUTTON_X+HORIZ_BUTTON_CARD_SPACE \
               and newY>=SIDE_BUTTON_Y and newY<=SIDE_BUTTON_Y+VERT_BUTTON_CARD_SPACE:
                Draw.clear()
                endGame(setsCompleted, boardList, deck, currentTime, minutes, seconds)
            
            #If they clicked the "No Sets" button,
            #check if there are actually no sets
            if newX>=SIDE_BUTTON_X and newX<=SIDE_BUTTON_X+HORIZ_BUTTON_CARD_SPACE \
               and newY>=SIDE_BUTTON_Y+VERT_CARD_SPACE and \
               newY <= SIDE_BUTTON_Y+VERT_CARD_SPACE+VERT_BUTTON_CARD_SPACE:
                #If there still are sets
                if setPossible(boardList)==True:
                    Draw.picture('Look_Again.gif', MESSAGE_MID_X, MESSAGE_MID_Y)
                    Draw.show()
                    time.sleep(.5)
                    
                #If there are no sets on the board
                elif setPossible(boardList)==False:
                    
                    #Deal three more cards, add these 
                    #cards to boardList and remove them from the deck
                    dealThree(setsCompleted, boardList, deck, currentTime, minutes, seconds)
                    
            #Initialize row and col to none
            row=None
            col=None
            
            #If a card was clicked, figure out what card it is
            
            #To find the row:
            #y=40-230, row 0
            if START_Y <= newY <= START_Y+CARD_LENGTH:
                row=0
            #y=240-430, row 1
            elif START_Y+VERT_CARD_SPACE <= newY <= START_Y+VERT_CARD_SPACE+CARD_LENGTH:
                row=1
            #y=440-630, row 2
            elif START_Y+VERT_CARD_SPACE*2 <= newY <= START_Y+VERT_CARD_SPACE*2+CARD_LENGTH:
                row=2
            
            #To find the col
            #x=40-190, col 0
            if START_X <= newX <= START_X+CARD_WIDTH:
                col=0
            #x=200-350, col 1
            elif START_X+HORIZ_CARD_SPACE <= newX <= START_X+HORIZ_CARD_SPACE+CARD_WIDTH:
                col=1
            #x=360-510, col 2
            elif START_X+HORIZ_CARD_SPACE*2 <= newX <= START_X+HORIZ_CARD_SPACE*2+CARD_WIDTH:
                col=2
            #x=520-670, col 3
            elif START_X+HORIZ_CARD_SPACE*3 <= newX <= START_X+HORIZ_CARD_SPACE*3+CARD_WIDTH:
                col=3
            #x=680-830, col 4
            elif START_X+HORIZ_CARD_SPACE*4 <= newX <= START_X+HORIZ_CARD_SPACE*4+CARD_WIDTH:
                col=4
                
            
            #If row and col exist, meaning a card had been selected
            #If this card is already in the hand, remove it from the hand
            if row!=None and col!=None and boardList[row][col] in clickedTry:
                
                #Find where the card occurs in the hand
                for i in range(len(clickedTry)):
                    if clickedTry[i] == boardList[row][col]:
                        #Delete the card
                        del clickedTry[i]
                        break
                        
            #If this card is not yet in the hand and is not an empty card, add it to the hand           
            elif row!=None and col!=None and boardList[row][col] not in clickedTry and boardList[row][col]!='':
                clickedTry+=[boardList[row][col]]   
                         
                    
        #Keep redrawing the board after each loop
        boardList, clickedTry, setsCompleted, startTime, deck, currentTime, minutes, seconds = drawBoard(boardList, clickedTry, setsCompleted, startTime, deck, currentTime, minutes, seconds)
        
        #I put this "check the hand" here so that the box around the selected card
        #appears for all 3 cards
        
        #If the hand is full, meaning it has 3 cards, check if it is a set or not
        if len(clickedTry)==3:
            checkSet(clickedTry)
            
            #If the hand was a correct set
            if checkSet(clickedTry)==True:
                
                #increment the score
                setsCompleted+=1
                
                #Remove the hand cards from the board and replace them
                boardList, clickedTry, deck=removeHand(boardList, clickedTry, deck)
                
                #Update the message
                Draw.picture('Great_Job.gif', MESSAGE_MID_X, MESSAGE_MID_Y)
                Draw.show()
    
                time.sleep(.5)                                    
            
            #If the hand was not a correct set
            elif checkSet(clickedTry)==False:
                
                #Update the message
                Draw.setColor(Draw.BLACK)
                Draw.picture('Try_Again.gif', MESSAGE_MID_X, MESSAGE_MID_Y)
                Draw.show()
    
                time.sleep(.5)
                
                #Clear the hand
                clickedTry=[]        
                    
    #Once you have falled out of the loop, meaning the game is over
    #end the game and display stats
    endGame(setsCompleted, boardList, deck, currentTime, minutes, seconds)
        
        
#Draw the game board with inputs of the 2D board list, current hand, 
#starting time, sets completed, and the updated deck
def drawBoard(boardList, clickedTry, setsCompleted, startTime, deck, currentTime, minutes, seconds):
    #Clear the canvas
    Draw.clear()
    
    #Calculate the current time, meaning how much time 
    #has passed since the start of the game
    #by subtracting the start time from the time it is now
    nowTime=time.time()
    currentTime=(nowTime-startTime)
    seconds=int(currentTime%60)
    minutes=int((currentTime//60))
    currentTime=str(minutes)+'\n'+str(seconds)
    
    #Enlarge the font size
    Draw.setFontSize(35)
    
    #Set font color
    Draw.setColor(NEW_GRAY)
    
    #Draw the "End Game" button
    Draw.picture('End_Game.gif', SIDE_BUTTON_X, SIDE_BUTTON_Y)
    
    
    #Draw the "No Sets" button
    Draw.picture('No_Sets.gif', SIDE_BUTTON_X, SIDE_BUTTON_Y+VERT_CARD_SPACE)
    
    ##Draw the Set logo
    #Draw.picture('Set_Logo_120_80.gif', SIDE_BUTTON_X, SIDE_BUTTON_Y+VERT_CARD_SPACE+VERT_CARD_SPACE)
    
    #Display the score
    Draw.string(setsCompleted, START_X, (START_Y+3*VERT_CARD_SPACE))
    if setsCompleted==1:
        Draw.picture('set_Completed.gif', \
                    START_X*2, (START_Y+3*VERT_CARD_SPACE))        
    else:
        Draw.picture('Sets_Completed.gif', \
                START_X*2, (START_Y+3*VERT_CARD_SPACE))
    
    #Display the amount of cards remaining in the deck
    Draw.string(len(deck), START_X, (START_Y*2+3*VERT_CARD_SPACE))
    Draw.picture('Cards_Remaining.gif', \
                START_X*2, (START_Y*2+3*VERT_CARD_SPACE))
    
    #Display the amount of time since the start of the game
    Draw.string(str(currentTime), \
                START_X, (START_Y*3+3*VERT_CARD_SPACE)) 
    
    
    
    
    
    
    
    
    #Draw.picture('Minutes.gif', \
                #START_X*2, (START_Y*3+3*VERT_CARD_SPACE))
    #Draw.picture('Seconds.gif', \
                #START_X*2, (START_Y*4+3*VERT_CARD_SPACE)) 
                
                
                
    if minutes == 1:
        Draw.picture('minute.gif', \
                    START_X*2, (START_Y*3+3*VERT_CARD_SPACE))
    else:
        Draw.picture('Minutes.gif', \
                START_X*2, (START_Y*3+3*VERT_CARD_SPACE))
    if seconds == 1:
        Draw.picture('second.gif', \
                START_X*2, (START_Y*4+3*VERT_CARD_SPACE))    
    else:
        Draw.picture('Seconds.gif', \
                START_X*2, (START_Y*4+3*VERT_CARD_SPACE))    
    
    
    #Draw the cards
    for row in range(len(boardList)):
        for col in range(len(boardList[0])):
            Draw.picture(boardList[row][col], \
                        START_X+(col)*(HORIZ_CARD_SPACE), \
                        START_Y+(row)*(VERT_CARD_SPACE))
            
            #If the card is in the hand and not a blank spot, draw a rectangle around it
            if boardList[row][col] in clickedTry and boardList[row][col]!='':
                Draw.picture('Rectangle.gif', \
                             START_X+(col)*(HORIZ_CARD_SPACE), \
                             START_Y+(row)*(VERT_CARD_SPACE))                

    #Display the canvas
    Draw.show()
    return boardList, clickedTry, setsCompleted, startTime, deck, currentTime, minutes, seconds
    
#Introduction game board page with start button
def introBoard(): 
    
    #Draw the Background and start button
    Draw.picture('Game Background (1100).gif', 0, 0)
    Draw.picture('Start_Game.gif', MESSAGE_X, MESSAGE_Y)

    ##Draw the Set logo
    #Draw.picture('Set_Logo_120_80.gif', LOGO_CENTER_X, LOGO_CENTER_Y)    
    
    startTime=0
    setsCompleted=0
    
    newX = 0
    newY = 0
    while True:
    #Check if the user clicked
    #If the user clicked, update the variables
        if Draw.mousePressed():
            newX = Draw.mouseX()
            newY = Draw.mouseY()    
            
            #If the start button was clicked, clear the board
            if newX>=MESSAGE_X and newX<=(MESSAGE_X+MESSAGE_WIDTH) \
               and newY>=MESSAGE_Y and newY<=(MESSAGE_Y+MESSAGE_LENGTH):
                Draw.clear()
                playGame()
           
def createDeck():
    
    #Creating the deck
    deck=[]
    
    #Lists of the different categories and options
    colorOptions = ['cr', 'cg', 'cp']
    shapeOptions = ['ss', 'so', 'sd']
    amountOptions = ['aon', 'atw', 'ath']
    filledOptions = ['ff', 'fh', 'fe']
    
    #Creating the deck of 81 cards
    for a in range(len(colorOptions)):
        for b in range(len(shapeOptions)):
            for c in range(len(amountOptions)):
                for d in range(len(filledOptions)):
                    deck += [colorOptions[a] + '_' + shapeOptions[b] + '_' +
                             amountOptions[c] + '_' + filledOptions[d] +
                             '.gif']    
    #Shuffle the deck
    random.shuffle(deck) 
    return deck

def fillBoardList(deck):
    #Board list keeps track of the cards on the board
    boardList=[[0 for col in range(5)] for col in range(3)]
    
    #Loop through the 2D boardList to fill in with cards
    for row in range(len(boardList)):
        for col in range(len(boardList[0])):
            
            #the left most column should remain empty in 
            #case we need to invoke dealThree
            if col==0:
                boardList[row][0]=''
            
            else:
                #Take the first card from the deck
                boardList[row][col]=deck[0]
                #Remove that card from the deck
                deck=deck[1:] 
    return boardList, deck

def endGame(setsCompleted, boardList, deck, currentTime, minutes, seconds):
    
    Draw.setColor(NEW_GRAY)
    
    #Clear the board
    Draw.clear()
    
    Draw.picture('Game Background (1100).gif', 0, 0)
    Draw.picture('Play_Again.gif', MESSAGE_X, MESSAGE_Y)
    
    ##Display the stats:
    
    ##Draw the Set logo
    #Draw.picture('Set_Logo_120_80.gif', LOGO_CENTER_X, LOGO_CENTER_Y)
    
    #Display the score
    Draw.string(setsCompleted, STRING_STAT_X, STAT_Y)
    if setsCompleted==1:
        Draw.picture('set_Completed.gif', \
                    GIF_STAT_X, STAT_Y)       
    else:
        Draw.picture('Sets_Completed.gif', \
                    GIF_STAT_X, STAT_Y)
    
    #Display the time
    Draw.string(currentTime, STRING_STAT_X, STAT_Y+STAT_SPACE)
    if minutes ==1:
        Draw.picture('minute.gif', \
                    GIF_STAT_X, STAT_Y+STAT_SPACE)
    else:
        Draw.picture('Minutes.gif', \
                GIF_STAT_X, STAT_Y+STAT_SPACE)
    if seconds==1:
        Draw.picture('second.gif', \
                GIF_STAT_X, STAT_Y+STAT_SPACE*2)    
    else:
        Draw.picture('Seconds.gif', \
                GIF_STAT_X, STAT_Y+STAT_SPACE*2)        
    
    Draw.show()
    
    newX = 0
    newY = 0
    
    while True:
    #Check if the user clicked
    #If the user clicked, update the variables
        if Draw.mousePressed():
            newX = Draw.mouseX()
            newY = Draw.mouseY()    
            
            #If the play again button was clicked, invoke intro board
            if newX>=MESSAGE_X and newX<=(MESSAGE_X+MESSAGE_WIDTH) \
               and newY>=MESSAGE_Y and newY<=(MESSAGE_Y+MESSAGE_LENGTH):
                Draw.clear()
                introBoard()
    
def setPossible(boardList):
    #Check if there is a potential set on the board
    #Store all of the elements in the 2D boardList in storage
    storage=[]
    
    for row in range(len(boardList)):
        for col in range(len(boardList[0])):
            #excluding the empty spaces
            if boardList[row][col]!='':
                storage+=[boardList[row][col]]

    #Loop through all of the elements and check if a set exists by
    #testing every pair of 3 option
    for x in range(len(storage)):
        for y in range(x+1,len(storage),1):
            for z in range(y+1,len(storage),1):
                #Check if the current hand is a set
                clickedTry=[storage[x],storage[y],storage[z]]
                #If a correct set is encountered, return true
                if checkSet(clickedTry)==True:
                    return True
                #Clear the hand
                clickedTry=[]
                
    #If no correct set is found in the board, return false
    return False
             
def checkSet(clickedTry):
    
    clickOne=clickedTry[0]
    clickTwo=clickedTry[1]
    clickThree=clickedTry[2]
    
    #Initialize all categories to false
    color=False
    shape=False
    amount=False
    filled=False
    
    #Check if all of the colors are the same, if they are color==True
    if clickOne[0:2]==clickTwo[0:2] and clickOne[0:2]==clickThree[0:2] \
    and clickTwo[0:2]==clickThree[0:2]:
        color=True
    #Check if all of the colors are different, if they are color==True
    if clickOne[0:2]!=clickTwo[0:2] and clickOne[0:2]!=clickThree[0:2] \
    and clickTwo[0:2]!=clickThree[0:2]:
        color=True
        
    #Check if all of the shapes are the same, if they are shape==True
    if clickOne[3:5]==clickTwo[3:5] and clickOne[3:5]==clickThree[3:5] \
    and clickTwo[3:5]==clickThree[3:5]:
        shape=True
    #Check if all of the shapes are different, if they are shape==True    
    if clickOne[3:5]!=clickTwo[3:5] and clickOne[3:5]!=clickThree[3:5] \
    and clickTwo[3:5]!=clickThree[3:5]:
        shape=True
        
    #Check if all of the amounts are the same, if they are amount==True
    if clickOne[6:9]==clickTwo[6:9] and clickOne[6:9]==clickThree[6:9] \
    and clickTwo[6:9]==clickThree[6:9]:
        amount=True
    #Check if all of the amount are different, if they are amount==True   
    if clickOne[6:9]!=clickTwo[6:9] and clickOne[6:9]!=clickThree[6:9] \
    and clickTwo[6:9]!=clickThree[6:9]:
        amount=True
    
    #Check if all of the fills are the same, if they are filled==True
    if clickOne[10:]==clickTwo[10:] and clickOne[10:]==clickThree[10:] \
    and clickTwo[10:]==clickThree[10:]:
        filled=True
    #Check if all of the fills are different, if they are filled==True 
    if clickOne[10:]!=clickTwo[10:] and clickOne[10:]!=clickThree[10:] \
    and clickTwo[10:]!=clickThree[10:]:
        filled=True
    
    #Now check all of the components
    return color==True and shape==True and amount==True and filled==True

def removeHand(boardList, clickedTry, deck):
    
    #In order to remove the hand from the board
    #loop through the board
    
    for i in range (len(boardList)):
        for row in range(len(boardList)):
            for col in range(len(boardList[0])):
                
                #if the hand has been emptied, return
                if len(clickedTry)==0:
                    return (boardList, clickedTry, deck) 
                
                #When the card in the hand is encountered
                elif boardList[row][col]==clickedTry[0]:           
                    
                    #If there are no cards left in the deck, add in an empty slot
                    if len(deck)==0:
                        boardList[row][col]=''
                   
                    #Fill the open slot in the main board with the "extra three"
                    #First make sure that the spot I am filling is in the main 12
                    #so col can not equal 0
                    
                   
                    #If the encountered card from the hand is in col 0
                    #make it empty
                    elif col==0:
                        boardList[row][col]=''
                    
                    #If the encountered card from the hand is in the main 12 section
                    #see if there is an extra card to fill its spot
                    elif col!=0 and (boardList[0][0]!='' or boardList[1][0]!='' \
                                     or boardList[2][0]!=''):
                        #Find the cards in the extra 3 slots
                        for j in range (len(boardList)):
                            if boardList[j][0]!='' and boardList[j][0] not in clickedTry:
                    
                                #Move them to the main board
                                boardList[row][col]=boardList[j][0]
                                
                                #Then make that spot empty
                                boardList[j][0]=''
                                
                                break
                             
                    
                    #Otherwise replace that card with the neck card from the deck
                    else:
                        boardList[row][col]=deck[0]
                        
                    #Update the hand
                    clickedTry=clickedTry[1:]
        
                    #Remove the new card from the deck
                    deck=deck[1:]   
    
    #Reset the hand to empty
    clickedTry=[]
                
    return (boardList, clickedTry, deck)

def dealThree(setsCompleted, boardList, deck, currentTime, minutes, seconds):
    #loop through the list looking for the "empty" spots
    if len(deck)>0:
        for row in range(len(boardList)):
            for col in range(len(boardList[0])):
                if boardList[row][col]=='':
                    
                    #Replace the empty card with the next card from the deck
                    boardList[row][col]=deck[0]
                    
                    #take that card off the deck
                    deck=deck[1:]
    else:
        endGame(setsCompleted, boardList, deck, currentTime, minutes, seconds)

    return boardList, deck
    
main()